#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tạo tệp bắt gói lab_marker.pcap (giả lập, chỉ dùng thư viện chuẩn Python) cho phần
“Suricata đọc tệp bắt gói” trên Ubuntu WSL – không cần máy ảo, không cần card mạng.

Nội dung: 3 phiên HTTP từ máy Kali giả lập 192.168.56.10 tới máy web giả lập 192.168.56.20:3000
  1) GET /                                   (truy cập bình thường)
  2) GET /rest/products/search?q=apple       (truy cập bình thường)
  3) GET /lab-marker-test                    (yêu cầu marker – phải sinh cảnh báo SID 1000001)
Cách dùng:  python3 sinh_pcap.py  [tệp_ra]   (mặc định lab_marker.pcap)"""
import struct, sys, time

def csum(b):
    if len(b) % 2: b += b'\0'
    s = sum(struct.unpack('!%dH' % (len(b) // 2), b))
    while s >> 16: s = (s & 0xffff) + (s >> 16)
    return (~s) & 0xffff

def ip4(a): return bytes(int(x) for x in a.split('.'))

MAC_C = bytes.fromhex('080027aa0a10'); MAC_S = bytes.fromhex('0800273a5c20')
C, S, SP = '192.168.56.10', '192.168.56.20', 3000
ipid = [1000]

def pkt(src, dst, sport, dport, seq, ack, flags, payload=b''):
    tcp = struct.pack('!HHIIBBHHH', sport, dport, seq, ack, 5 << 4, flags, 64240, 0, 0) + payload
    pseudo = ip4(src) + ip4(dst) + struct.pack('!BBH', 0, 6, len(tcp))
    tcp = tcp[:16] + struct.pack('!H', csum(pseudo + tcp)) + tcp[18:]
    ipid[0] += 1
    iph = struct.pack('!BBHHHBBH4s4s', 0x45, 0, 20 + len(tcp), ipid[0], 0x4000, 64, 6, 0, ip4(src), ip4(dst))
    iph = iph[:10] + struct.pack('!H', csum(iph)) + iph[12:]
    eth = (MAC_S + MAC_C if src == C else MAC_C + MAC_S) + b'\x08\x00'
    return eth + iph + tcp

def session(t0, cport, path):
    req = ('GET %s HTTP/1.1\r\nHost: 192.168.56.20:3000\r\nUser-Agent: curl/8.5.0\r\nAccept: */*\r\n\r\n' % path).encode()
    body = b'{"status":"success","data":[]}' if path.startswith('/rest') else (b'<html><body>Cong thu nghiem (gia lap)</body></html>' if path == '/' else b'Not Found')
    code = b'200 OK' if path != '/lab-marker-test' else b'404 Not Found'
    resp = b'HTTP/1.1 ' + code + b'\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ' + str(len(body)).encode() + b'\r\nConnection: close\r\n\r\n' + body
    cs, ss = 100000 + cport, 500000 + cport
    F, SY, R, P, A = 1, 2, 4, 8, 16
    seq = [
      (C, S, cport, SP, cs, 0, SY),
      (S, C, SP, cport, ss, cs + 1, SY | A),
      (C, S, cport, SP, cs + 1, ss + 1, A),
      (C, S, cport, SP, cs + 1, ss + 1, P | A, req),
      (S, C, SP, cport, ss + 1, cs + 1 + len(req), A),
      (S, C, SP, cport, ss + 1, cs + 1 + len(req), P | A, resp),
      (C, S, cport, SP, cs + 1 + len(req), ss + 1 + len(resp), A),
      (C, S, cport, SP, cs + 1 + len(req), ss + 1 + len(resp), F | A),
      (S, C, SP, cport, ss + 1 + len(resp), cs + 2 + len(req), F | A),
      (C, S, cport, SP, cs + 2 + len(req), ss + 2 + len(resp), A)]
    out = []
    for i, p in enumerate(seq):
        out.append((t0 + i * 0.002, pkt(*p)))
    return out

def main():
    fn = sys.argv[1] if len(sys.argv) > 1 else 'lab_marker.pcap'
    # 16/11/2026 10:05:00 +07:00 = 03:05:00 UTC
    t0 = 1794798300.0
    pk = session(t0, 41001, '/') + session(t0 + 5, 41002, '/rest/products/search?q=apple') + session(t0 + 12, 41003, '/lab-marker-test')
    with open(fn, 'wb') as f:
        f.write(struct.pack('<IHHiIII', 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1))
        for ts, p in pk:
            f.write(struct.pack('<IIII', int(ts), int((ts % 1) * 1e6), len(p), len(p)) + p)
    print('Đã tạo %s: %d gói, 3 phiên HTTP (192.168.56.10 → 192.168.56.20:3000)' % (fn, len(pk)))

if __name__ == '__main__':
    main()
