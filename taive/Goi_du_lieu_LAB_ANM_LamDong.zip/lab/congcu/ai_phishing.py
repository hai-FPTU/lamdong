#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Lab mở rộng – huấn luyện mô hình nhẹ phát hiện thư lừa đảo (chỉ dùng thư viện chuẩn của Python).

Mô hình: hồi quy logistic, học bằng giảm dần độ dốc (gradient descent) – cùng thuật toán,
cùng tham số với công cụ trên giáo trình web, nên hai bên ra cùng kết quả.

Ví dụ:
  python3 ai_phishing.py                       # 10 đặc trưng cơ bản, ngưỡng 0.5
  python3 ai_phishing.py --nguong 0.8          # đổi ngưỡng chặn
  python3 ai_phishing.py --dac-trung spf_khong_dat,ten_mien_na_na
  python3 ai_phishing.py --them yeu_cau_nhay_cam    # vòng 2: thêm đặc trưng mới
  python3 ai_phishing.py --thu thu_ne_tranh.csv     # đánh giá trên bộ thư né tránh
Tham số --du-lieu trỏ tới thư mục chứa các tệp CSV (mặc định: ../dulieu so với tệp này, hoặc thư mục hiện tại).
"""
import csv, math, os, sys, argparse

DAC_TRUNG = [
    ('spf_khong_dat', 'SPF không đạt (fail/none)', lambda r: 1.0 if r['spf'] != 'pass' else 0.0),
    ('dkim_khong_dat', 'DKIM không đạt (fail/none)', lambda r: 1.0 if r['dkim'] != 'pass' else 0.0),
    ('reply_to_khac', 'Reply-To khác người gửi', lambda r: float(r['reply_to_khac'])),
    ('ten_mien_na_na', 'Tên miền na ná tên miền quen', lambda r: float(r['ten_mien_na_na'])),
    ('lien_ket_khac_hien_thi', 'Liên kết thật khác chữ hiển thị', lambda r: float(r['lien_ket_khac_hien_thi'])),
    ('dinh_kem_nguy_hiem', 'Đính kèm .html/.zip/.docm/.iso', lambda r: 1.0 if r['dinh_kem'] in ('html', 'zip', 'docm', 'iso') else 0.0),
    ('tu_khan_cap', 'Lời lẽ khẩn cấp (0–3 từ)', lambda r: min(int(r['tu_khan_cap']), 3) / 3.0),
    ('ben_ngoai', 'Gửi từ bên ngoài cơ quan', lambda r: float(r['ben_ngoai'])),
    ('lan_dau_lien_lac', 'Lần đầu liên lạc', lambda r: float(r['lan_dau_lien_lac'])),
    ('nhieu_lien_ket', 'Số liên kết (0–5)', lambda r: min(int(r['so_lien_ket']), 5) / 5.0),
    ('yeu_cau_nhay_cam', 'Yêu cầu nhạy cảm (mật khẩu, tiền, tài liệu)', lambda r: float(r['yeu_cau_nhay_cam'])),
]
CO_BAN = [d[0] for d in DAC_TRUNG[:10]]
HOC = dict(lr=1.0, lam=0.001, vong=500)

def doc(fn):
    with open(fn, encoding='utf-8') as f: return list(csv.DictReader(f))

def ma_tran(rows, chon):
    fs = [d for d in DAC_TRUNG if d[0] in chon]
    X = [[d[2](r) for d in fs] for r in rows]
    y = [1.0 if r['nhan'] == 'lừa đảo' else 0.0 for r in rows]
    return X, y, fs

def huan_luyen(X, y, lr=HOC['lr'], lam=HOC['lam'], vong=HOC['vong']):
    n, m = len(X), len(X[0])
    w, b = [0.0] * m, 0.0
    for _ in range(vong):
        gw, gb = [0.0] * m, 0.0
        for i in range(n):
            z = b
            for j in range(m): z += w[j] * X[i][j]
            g = 1.0 / (1.0 + math.exp(-z)) - y[i]
            for j in range(m): gw[j] += g * X[i][j]
            gb += g
        for j in range(m): w[j] -= lr * (gw[j] / n + lam * w[j])
        b -= lr * gb / n
    return w, b

def diem(w, b, x):
    z = b
    for j in range(len(w)): z += w[j] * x[j]
    return 1.0 / (1.0 + math.exp(-z))

def danh_gia(w, b, X, y, nguong):
    tp = fp = fn = tn = 0
    for x, t in zip(X, y):
        d = diem(w, b, x) >= nguong
        if d and t: tp += 1
        elif d and not t: fp += 1
        elif not d and t: fn += 1
        else: tn += 1
    pr = tp / (tp + fp) if tp + fp else 0.0
    rc = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * pr * rc / (pr + rc) if pr + rc else 0.0
    return dict(tp=tp, fp=fp, fn=fn, tn=tn, acc=(tp + tn) / len(y), pr=pr, rc=rc, f1=f1)

def in_kq(ten, k):
    print('  %-28s chặn đúng %3d | chặn nhầm %3d | lọt %3d | cho qua đúng %3d | chính xác %.1f%% | độ chuẩn xác %.1f%% | độ phủ %.1f%%'
          % (ten, k['tp'], k['fp'], k['fn'], k['tn'], k['acc'] * 100, k['pr'] * 100, k['rc'] * 100))

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Huấn luyện mô hình nhẹ phát hiện thư lừa đảo (dữ liệu giả lập).')
    ap.add_argument('--du-lieu', default=None)
    ap.add_argument('--dac-trung', default=','.join(CO_BAN))
    ap.add_argument('--them', default='')
    ap.add_argument('--nguong', type=float, default=0.5)
    ap.add_argument('--thu', default='thu_kiem_tra.csv')
    a = ap.parse_args()
    here = os.path.dirname(os.path.abspath(__file__))
    dl = a.du_lieu or next((d for d in [os.path.join(here, '..', 'dulieu'), '.', 'dulieu'] if os.path.exists(os.path.join(d, 'thu_huan_luyen.csv'))), '.')
    chon = [c for c in (a.dac_trung + ',' + a.them).split(',') if c]
    hl, kt = doc(os.path.join(dl, 'thu_huan_luyen.csv')), doc(os.path.join(dl, a.thu))
    X, y, fs = ma_tran(hl, chon); Xt, yt, _ = ma_tran(kt, chon)
    print('Tập huấn luyện: %d thư (%d lừa đảo) · Tập đánh giá %s: %d thư (%d lừa đảo)' % (len(y), sum(y), a.thu, len(yt), sum(yt)))
    w, b = huan_luyen(X, y)
    print('\nTrọng số đã học (dương = làm tăng điểm nghi ngờ):')
    for d, wj in sorted(zip(fs, w), key=lambda t: -t[1]): print('  %+7.3f  %-24s %s' % (wj, d[0], d[1]))
    print('  %+7.3f  (hệ số chặn)' % b)
    print('\nKết quả trên %s:' % a.thu)
    in_kq('Quy tắc “SPF không đạt”', danh_gia([1.0], -0.5, [[1.0 if r['spf'] != 'pass' else 0.0] for r in kt], yt, 0.5))
    for ng in sorted({0.3, 0.5, 0.7, 0.9, a.nguong}):
        in_kq('Mô hình, ngưỡng %.2f' % ng, danh_gia(w, b, Xt, yt, ng))
