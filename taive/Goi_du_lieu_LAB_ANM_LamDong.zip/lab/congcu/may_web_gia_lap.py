#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Máy web giả lập cho thực hành trên Ubuntu WSL (chỉ dùng thư viện chuẩn Python).

Mô phỏng “máy web của phòng lab” (cổng thử nghiệm, kiểu phản hồi giống ứng dụng Node.js/Express
trong tệp http_mau.txt) để học viên làm Lab 3 – 4 mà không cần máy ảo:
  • kiểm tra trạng thái ứng dụng:          curl -sI http://127.0.0.1:3000/
  • quan sát một yêu cầu GET hợp lệ:       curl -sv "http://127.0.0.1:3000/rest/products/search?q=apple"
  • gửi yêu cầu marker kiểm thử:            curl -s -o /dev/null -w '%{http_code}\\n' http://127.0.0.1:3000/lab-marker-test
Mỗi yêu cầu được ghi vào nhật ký theo định dạng combined (giống web_access.log) để tự phân tích.

AN TOÀN: mặc định chỉ nghe 127.0.0.1 – chỉ chính máy này truy cập được. Không có dữ liệu thật.
Tuỳ chọn --tren-may-ao: nghe 0.0.0.0 – CHỈ dùng trong mạng cô lập của phòng lab máy ảo (Lab 8).

Cách dùng:
  python3 may_web_gia_lap.py                    # chạy, nhật ký ở ~/lab/ketqua/web_gia_lap_access.log
  python3 may_web_gia_lap.py &                  # chạy nền; dừng bằng: pkill -f may_web_gia_lap.py
  python3 may_web_gia_lap.py --cong 3000 --nhat-ky duong/dan.log
"""
import argparse, json, os, sys, time, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SP = [{"id": 1, "name": "Apple Juice (1000ml)", "price": 1.99}, {"id": 2, "name": "Orange Juice (1000ml)", "price": 2.99},
      {"id": 3, "name": "Banana Juice (1000ml)", "price": 1.99}, {"id": 4, "name": "Lemon Juice (500ml)", "price": 2.49}]
TRANG = ('<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><title>Cổng thử nghiệm – phòng lab (giả lập)</title></head>'
         '<body><h1>Cổng thử nghiệm của phòng lab</h1><p>Máy web giả lập phục vụ tập huấn. Không chứa dữ liệu thật.</p>'
         '<p>API: <code>/rest/products/search?q=</code></p></body></html>')

class XuLy(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    nhat_ky = None

    def send_response(self, code, message=None):
        # Giống Express: không gửi tiêu đề Server
        self.log_request(code); self.send_response_only(code, message); self.send_header('Date', self.date_time_string())

    def log_message(self, fmt, *args):
        pass

    def ghi(self, code, n):
        ua = self.headers.get('User-Agent', '-'); ref = self.headers.get('Referer', '-')
        t = time.strftime('%d/%b/%Y:%H:%M:%S %z')
        dong = '%s - - [%s] "%s" %d %d "%s" "%s"\n' % (self.client_address[0], t, self.requestline, code, n, ref, ua)
        with open(self.nhat_ky, 'a', encoding='utf-8') as f: f.write(dong)

    def tra(self, code, kieu, than, them=()):
        b = than.encode('utf-8')
        self.send_response(code)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'SAMEORIGIN')
        self.send_header('Feature-Policy', "payment 'self'")
        for k, v in them: self.send_header(k, v)
        self.send_header('Content-Type', kieu)
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        if self.command != 'HEAD': self.wfile.write(b)
        self.ghi(code, len(b))

    def do_GET(self):
        u = urllib.parse.urlsplit(self.path)
        if u.path in ('/', '/index.html'):
            return self.tra(200, 'text/html; charset=utf-8', TRANG)
        if u.path == '/rest/products/search':
            q = urllib.parse.parse_qs(u.query).get('q', [''])[0].lower()
            kq = [p for p in SP if q in p['name'].lower()]
            return self.tra(200, 'application/json; charset=utf-8', json.dumps({'status': 'success', 'data': kq}, ensure_ascii=False))
        if u.path == '/robots.txt':
            return self.tra(200, 'text/plain; charset=utf-8', 'User-agent: *\nDisallow: /ftp\n')
        return self.tra(404, 'text/html; charset=utf-8', '<!DOCTYPE html><html><body><pre>Cannot GET %s</pre></body></html>' % u.path.replace('<', '&lt;'))

    do_HEAD = do_GET

    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0)
        if n: self.rfile.read(min(n, 65536))
        return self.tra(405, 'application/json; charset=utf-8', '{"status":"error","message":"Máy giả lập không nhận dữ liệu gửi lên"}')

class MayChu(ThreadingHTTPServer):
    daemon_threads = True
    def handle_error(self, request, client_address):
        pass  # bỏ qua yêu cầu hỏng (ví dụ gói thăm dò của nmap -sV), không in lỗi ra màn hình

def main():
    ap = argparse.ArgumentParser(description='Máy web giả lập cho thực hành trên Ubuntu WSL')
    ap.add_argument('--cong', type=int, default=3000, help='cổng nghe (mặc định 3000)')
    ap.add_argument('--nhat-ky', default=os.path.expanduser('~/lab/ketqua/web_gia_lap_access.log'))
    ap.add_argument('--tren-may-ao', action='store_true', help='nghe 0.0.0.0 – chỉ dùng trong mạng cô lập của phòng lab máy ảo')
    a = ap.parse_args()
    os.makedirs(os.path.dirname(os.path.abspath(a.nhat_ky)), exist_ok=True)
    XuLy.nhat_ky = a.nhat_ky
    dc = '0.0.0.0' if a.tren_may_ao else '127.0.0.1'
    try:
        sv = MayChu((dc, a.cong), XuLy)
    except OSError as e:
        sys.exit('Không mở được cổng %d (%s). Có thể máy web giả lập đang chạy rồi: pkill -f may_web_gia_lap.py' % (a.cong, e))
    print('Máy web giả lập đang nghe http://%s:%d/  · nhật ký: %s  · dừng: Ctrl+C hoặc pkill -f may_web_gia_lap.py' % (dc, a.cong, a.nhat_ky), flush=True)
    try: sv.serve_forever()
    except KeyboardInterrupt: pass

if __name__ == '__main__':
    main()
