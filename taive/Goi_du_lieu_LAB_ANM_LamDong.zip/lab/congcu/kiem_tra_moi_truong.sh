#!/usr/bin/env bash
# Kiểm tra máy thực hành (Ubuntu trên WSL hoặc Ubuntu/Kali). Chạy:  bash ~/lab/congcu/kiem_tra_moi_truong.sh
LAB="${LAB:-$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)}"; [ -d "$LAB/dulieu" ] || LAB="$HOME/lab"
ok(){ printf '  [ĐẠT]   %s\n' "$1"; }
no(){ printf '  [THIẾU]  %s\n' "$1"; LOI=$((LOI+1)); }
tc(){ printf '  [—]      %s\n' "$1"; }
LOI=0
echo "KIỂM TRA MÔI TRƯỜNG THỰC HÀNH – An ninh mạng và bảo vệ HTTT (dữ liệu giả lập)"
echo "1. Hệ điều hành"
if grep -qi microsoft /proc/version 2>/dev/null; then
  if grep -qi wsl2 /proc/version; then ok "Ubuntu chạy trên WSL 2"; else ok "Ubuntu chạy trên WSL (bản 1 – đủ cho phân tích log)"; fi
else ok "Linux: $(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-không rõ}")"; fi
ID_OS=$(. /etc/os-release 2>/dev/null; echo "$ID")
if [ "$ID_OS" = "ubuntu" ]; then ok "Bản Linux: Ubuntu"; else tc "Bản Linux là \"$ID_OS\", không phải Ubuntu – lệnh cài đặt trong cẩm nang viết cho Ubuntu 24.04"; fi
echo "2. Công cụ bắt buộc"
for c in grep awk sort uniq jq column python3 curl sha256sum sha512sum; do
  if command -v $c >/dev/null 2>&1; then ok "$c"; else no "$c  → bash ~/lab/congcu/cai_dat_cong_cu.sh"; fi
done
echo "3. Công cụ tuỳ chọn (Lab 3–4 phần nâng cao)"
for c in suricata nmap; do
  if command -v $c >/dev/null 2>&1; then ok "$c"; else tc "$c chưa cài (tuỳ chọn) → bash ~/lab/congcu/cai_dat_cong_cu.sh"; fi
done
echo "4. Bộ dữ liệu"
if [ -d "$LAB/dulieu" ]; then
  n=$(ls "$LAB/dulieu" | grep -v ':Zone.Identifier$' | wc -l); [ "$n" -ge 20 ] && ok "$LAB/dulieu có $n tệp" || no "$LAB/dulieu chỉ có $n tệp (cần 20)"
  z=$(find "$LAB" -name '*:Zone.Identifier' | wc -l)
  [ "$z" -gt 0 ] && { tc "Có $z tệp phụ *:Zone.Identifier do Windows tạo – đã xoá"; find "$LAB" -name '*:Zone.Identifier' -delete; }
  if [ -f "$LAB/congcu/SHA512SUMS" ]; then
    if (cd "$LAB" && sha512sum -c --quiet congcu/SHA512SUMS >/dev/null 2>&1); then ok "Mã băm SHA-512 của 20 tệp khớp – dữ liệu nguyên vẹn"
    else no "Mã băm KHÔNG khớp – dán lại khối lệnh chép dữ liệu (không mở, không sửa tệp bằng Notepad/Excel)"; fi
  fi
else no "Không thấy $LAB/dulieu – dán khối lệnh chép dữ liệu ở trang Cài Ubuntu WSL"; fi
echo "5. Hiển thị tiếng Việt"
if locale 2>/dev/null | grep -qi 'utf-\?8'; then ok "Bảng mã UTF-8"; else no "Chưa dùng UTF-8 → echo 'export LANG=C.UTF-8' >> ~/.bashrc && source ~/.bashrc"; fi
echo "6. Cổng 3000 cho máy web giả lập"
if (exec 3<>/dev/tcp/127.0.0.1/3000) 2>/dev/null; then tc "Cổng 3000 đang có chương trình nghe (máy web giả lập đã chạy?)"; else ok "Cổng 3000 còn trống"; fi
echo
if [ "$LOI" -eq 0 ]; then echo "KẾT QUẢ: máy đã sẵn sàng."; else echo "KẾT QUẢ: còn $LOI mục cần xử lý (xem dòng [THIẾU])."; fi
