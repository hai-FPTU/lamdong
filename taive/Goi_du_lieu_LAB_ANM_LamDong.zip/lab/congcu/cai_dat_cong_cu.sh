#!/usr/bin/env bash
# Cài công cụ cho thực hành trên Ubuntu (WSL), rồi tự kiểm tra môi trường.
#   bash ~/lab/congcu/cai_dat_cong_cu.sh            # đủ công cụ cho mọi lab (jq, column, unzip, curl, suricata, nmap)
#   bash ~/lab/congcu/cai_dat_cong_cu.sh --co-ban   # chỉ công cụ phân tích nhật ký (không suricata, nmap)
# Máy đã có đủ công cụ thì không cài gì, không hỏi mật khẩu.
LAB="$(cd "$(dirname "$0")/.." && pwd)"
CAN="jq bsdextrautils unzip curl python3"; LENH="jq column unzip curl python3"
if [ "$1" != "--co-ban" ]; then CAN="$CAN suricata nmap"; LENH="$LENH suricata nmap"; fi
THIEU=""
for c in $LENH; do command -v "$c" >/dev/null 2>&1 || THIEU="$THIEU $c"; done
if [ -z "$THIEU" ]; then
  echo "== Đã có đủ công cụ, không cần cài thêm."
elif ! command -v apt-get >/dev/null 2>&1; then
  echo "!! Máy này không phải Ubuntu (không có apt-get). Mở Ubuntu 24.04 rồi chạy lại."; exit 1
else
  echo "== Cần cài:$THIEU"
  echo "== Ubuntu sẽ hỏi mật khẩu: gõ mật khẩu Ubuntu (không hiện ký tự) rồi Enter. Cần Internet, mất vài phút."
  SUDO=sudo; [ "$(id -u)" = 0 ] && SUDO=
  $SUDO apt-get update -qq && DEBIAN_FRONTEND=noninteractive $SUDO apt-get install -y -qq $CAN >/dev/null \
    && echo "== Đã cài xong." || echo "!! Cài chưa xong – kiểm tra Internet rồi chạy lại: bash ~/lab/congcu/cai_dat_cong_cu.sh"
  # Lab chỉ cho Suricata ĐỌC TỆP bắt gói, không giám sát card mạng → tắt dịch vụ chạy nền nếu có
  if command -v suricata >/dev/null 2>&1 && command -v systemctl >/dev/null 2>&1; then
    $SUDO systemctl disable --now suricata >/dev/null 2>&1 || true
  fi
fi
echo
bash "$LAB/congcu/kiem_tra_moi_truong.sh"
